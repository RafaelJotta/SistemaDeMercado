#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

typedef struct preco PRECO;
struct preco{
    float preco;
};

typedef struct produto PRODUTO;
struct produto{
    char nome[50];
    char descricao[500];
    char codProduto[10];
    PRECO precos; 
};

void cabecalho();
void inputData();
void listar();
void pesquisar();
void remover();


main(){
    int opcao;
    do{
        cabecalho();
        printf("1 - Inserir Produto\n");
        printf("2 - Remover Produto!\n");
        printf("3 - Pesquisar um produto pelo nome:\n");
        printf("4 - Listar todos os produtos.\n");
        printf("5 - Sair\n\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao){
        case 1:
            inputData();
            break;
        case 2:
            remover();
            break;
        case 3:
            pesquisar();
            break;
        case 4:
            listar();
            break;
        
        case 5:
            printf("Obrigado por sua visita!\n");
            getch();
            return 0;
            break;

        default:
            printf("Opcao invalida!\n");
            getch();
            break;
        }
    }while(opcao != 7);
}

void cabecalho(){
    system("cls");
    printf("---------------------------------------\n");
    printf("         MERCADO DO JOTTA\n");
    printf("---------------------------------------\n\n");
}

void inputData(){
    FILE* arquivo;
    PRODUTO ctt;    


    arquivo = fopen("mercado.txt", "ab");
    if(arquivo == NULL){
        printf("Problema, erro!\n");
    }
    else{
        do{
            cabecalho();
            fflush(stdin);
            printf("Cadastre o nome do produto: ");
            gets(ctt.nome);

            fflush(stdin);
            printf("Cadastre a descricao: ");
            gets(ctt.descricao);

            printf("Cadastre o valor do produto: ");
            scanf("%f",&ctt.precos.preco);

            fflush(stdin);
            printf("Cadastre o codigo do produto: ");
            gets(ctt.codProduto);

            fwrite(&ctt, sizeof(PRODUTO), 1, arquivo);

            printf("Deseja continuar(s/n)?");

        }while(getche() == 's');
        fclose(arquivo);
    }
}

void listar(){
    FILE* arquivo;
    PRODUTO ctt;    


    arquivo = fopen("mercado.txt", "rb");

    cabecalho();
    if(arquivo == NULL){
        printf("Problema, erro!\n");
    }
    else{
        while ( fread(&ctt, sizeof(PRODUTO), 1, arquivo)==1){
            printf("Produto: %s\n", ctt.nome);
            printf("Descricao: %s\n", ctt.descricao);
            printf("Valor produto: %.2fR$\n", ctt.precos.preco);
            printf("Codigo do produto: %s\n", ctt.codProduto);
            printf("------------------------------\n\n");
        }
        printf("Aperte qualquer tecla, para ao voltar menu inicial!");
    }
    fclose(arquivo);
    getch();
}

void pesquisar(){
    FILE* arquivo;
    PRODUTO ctt;
    char nome[50];    

    cabecalho();
    arquivo = fopen("mercado.txt", "rb");
    if(arquivo == NULL){
        printf("Problema, erro!\n");
    }
    else{
        fflush(stdin);
        printf("Digite o produto a pesquisar: ");
        gets(nome);

        while( fread(&ctt, sizeof(PRODUTO), 1, arquivo)==1){
            if(strcmp(nome,ctt.nome)==0){
                printf("Produto: %s\n", ctt.nome);
                printf("Descricao: %s\n", ctt.descricao);
                printf("Valor produto: %.2fR$\n", ctt.precos.preco);
                printf("Codigo do produto: %s\n", ctt.codProduto);
                printf("------------------------------\n\n");
            }
            if(strstr(ctt.descricao,nome)!=NULL){
                printf("Produto: %s\n", ctt.nome);
                printf("Descricao: %s\n", ctt.descricao);
                printf("Valor produto: %.2fR$\n", ctt.precos.preco);
                printf("Codigo do produto: %s\n", ctt.codProduto);
                printf("------------------------------\n\n");
            }
            else{
                printf("\nProduto nao encontrado");
            }
        }
        printf("\n\nAperte qualquer tecla, para ao voltar menu inicial!\n");
    }
    fclose(arquivo);
    getch();
}

void remover(){
    FILE* arquivo;
    FILE* temp;
    PRODUTO ctt;
    int nome[5];
 
    arquivo = fopen("mercado.txt","rb");
    temp = fopen("tmp.txt","wb");
    if(arquivo==NULL&&temp==NULL){
        printf("Problemas na abertura do arquivo!\n");
        getch();
    }
    else{
        cabecalho();
        fflush(stdin);
        printf("Digite o codigo do produto a deletar: ");
        gets(nome);
    while(fread(&ctt,sizeof(PRODUTO),1,arquivo)==1){
    if(strcmp(nome,ctt.codProduto)==0){
                printf("Produto: %s\n", ctt.nome);
                printf("Descricao: %s\n", ctt.descricao);
                printf("Valor produto: %.2fR$\n", ctt.precos.preco);
                printf("Codigo do produto: %s\n", ctt.codProduto);
                printf("------------------------------\n\n");
    }
    else{
    fwrite(&ctt,sizeof(PRODUTO),1,temp);
   }
  }
  fclose(arquivo);
  fclose(temp);
  fflush(stdin);
  printf("Deseja deletar (s/n)? ");
  if(getche()=='s'){
   
   if(remove("mercado.txt")==0&&rename("tmp.txt","mercado.txt")==0){
    printf("\nOperacao realizada com sucesso!");
   }else{
    remove("tmp.txt");
   }
  }
  fclose(temp);
  fclose(arquivo);
  getch();
 } 
}




