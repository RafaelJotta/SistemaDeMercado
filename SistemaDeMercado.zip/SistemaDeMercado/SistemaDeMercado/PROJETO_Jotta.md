---------------------------------------
MERCADO DO JOTTA
---------------------------------------

1 - Inserir Produto (aqui voce vai pra outra tela! onde vai armazenar o nome do produto, a descriçao, o valor e o codigo do produto.)
2 - Remover Produto! (remove o produto pelo codigo do produto)
3 - Pesquisar um produto pelo nome: 
4 - Listar todos os produtos.
5 - Sair

Escolha uma opcao:

obs(na hora de remover o produto coloquei char, porque nao tava conseguindo com int... mas ta funcionando kkk)